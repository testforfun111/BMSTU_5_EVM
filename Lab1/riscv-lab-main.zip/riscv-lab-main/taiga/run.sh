#!/bin/sh
vsim -do "do scripts/run.do ../src/test.hex"
